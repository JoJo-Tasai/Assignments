#!/usr/bin/env python
# coding: utf-8

# In[19]:


# 使用numpy实现Boston房价预测
import numpy as np
import torch
from torch import nn
from sklearn.datasets import load_boston
from sklearn.utils import shuffle, resample

# 数据加载
data = load_boston()
#特征值矩阵
X = data['data']
#房价y
y = data['target']
print(X.shape)
print(y.shape)
y = y.reshape(-1,1)

from sklearn.preprocessing import MinMaxScaler
#数据规范化
ss = MinMaxScaler()
X = ss.fit_transform(X)

#数据集切分
X = torch.from_numpy(X).type(torch.FloatTensor)
y = torch.from_numpy(y).type(torch.FloatTensor)
from sklearn.model_selection import train_test_split
train_x, test_x, train_y, test_y = train_test_split(X, y, test_size=0.25)

#构建网络
model = nn.Sequential(
    #输入的是13，16是神经元个数 
    nn.Linear(13,16),
    nn.ReLU(),
    nn.Linear(16,1),
)

#定义优化器和损失函数
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(),lr=0.01)

#训练
max_epoch = 300
iter_loss = []
for i in range(max_epoch):
    #对输入的值进行预测
    y_pred = model(X)
    #计算loss
    loss = criterion(y_pred, y)
    #因为loss只有一个值
    iter_loss.append(loss.item())
    #清空上一轮梯度(pytorch里比较特殊，如果不清空，每次梯度会累加，导致梯度很大)
    #grad_w1,grad_w2
    optimizer.zero_grad()
    #反向传播
    loss.backward()
    #调整权重
    optimizer.step()
    
#测试
output = model(test_x)
predict_list = output.detach().numpy()
print(predict_list)

import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
#绘制真实值与预测值的散点图
x = np.arange(test_x.shape[0])
y1 = np.array(predict_list)
y2 = np.array(test_y)

#预测用红色，真实值用黄色
line1 = plt.scatter(x, y1, c='red')
line2 = plt.scatter(x, y2, c='yellow')
plt.legend([line1,line2], ['predict', 'real'], loc=1)
plt.title('Prediction VS Real')
plt.ylabel('House Price')
plt.show()

